#include <bits/stdc++.h>
using namespace std;

int main() {
    string filename = "input.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Cannot open file " << filename << endl;
        return 1;
    }
    string line;
    getline(file, line); 
    vector<double> x, y;
    while (getline(file, line)) {
        stringstream ss(line);
        string val1, val2;
        getline(ss, val1, ',');
        getline(ss, val2, ',');
        if (!val1.empty() && !val2.empty()) {
            x.push_back(stod(val1));
            y.push_back(stod(val2));
        }
    }
    file.close();
    int n = x.size();
    double sumx = 0, sumy = 0, sumxy = 0, sumx2 = 0;
    for (int i = 0; i < n; i++) {
        sumx += x[i];
        sumy += y[i];
        sumxy += x[i] * y[i];
        sumx2 += x[i] * x[i];
    }

    double m = (n * sumxy - sumx * sumy) / (n * sumx2 - sumx * sumx);
    double c = (sumy * sumx2 - sumx * sumxy) / (n * sumx2 - sumx * sumx);
    cout << fixed << setprecision(3);
    cout << "Sum(x) = " << sumx << endl;
    cout << "Sum(y) = " << sumy << endl;
    cout << "Sum(x^2) = " << sumx2 << endl;
    cout << "Sum(xy) = " << sumxy << endl << endl;
    cout << "Slope (m) = " << m << endl;
    cout << "Intercept (c) = " << c << endl;
    cout << "\nEquation of line: y = " << m << "x + " << c << endl;
    return 0;
}

// #include <bits/stdc++.h>
// using namespace std;
// int main() {
//     string filename;
//     cout << "Enter CSV filename: ";
//     getline(cin, filename);

//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: Cannot open file " << filename << endl;
//         return 1;
//     }

//     // Skip header row
//     string line;
//     getline(file, line);

//     // Ask which columns to use for X and Y
//     cout << "Enter column indices for X and Y (space separated, 0-based): ";
//     int xCol, yCol;
//     cin >> xCol >> yCol;

//     vector<double> x, y;
//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string token;
//         vector<string> values;
//         while (getline(ss, token, ','))
//             values.push_back(token);

//         // Safely convert selected columns to double
//         try {
//             double xv = stod(values[xCol]);
//             double yv = stod(values[yCol]);
//             x.push_back(xv);
//             y.push_back(yv);
//         } catch (...) {
//             // Ignore non-numeric or missing values
//             continue;
//         }
//     }
//     file.close();

//     int n = x.size();
//     if (n < 2) {
//         cerr << "Error: Not enough valid numeric data found.\n";
//         return 1;
//     }

//     // --- Compute Sums ---
//     double sumx = 0, sumy = 0, sumxy = 0, sumx2 = 0;
//     for (int i = 0; i < n; i++) {
//         sumx += x[i];
//         sumy += y[i];
//         sumxy += x[i] * y[i];
//         sumx2 += x[i] * x[i];
//     }

//     // --- Compute Regression Parameters ---
//     double m = (n * sumxy - sumx * sumy) / (n * sumx2 - sumx * sumx);
//     double c = (sumy * sumx2 - sumx * sumxy) / (n * sumx2 - sumx * sumx);

//     // --- Print Results ---
//     cout << fixed << setprecision(3);
//     cout << "\nStatistical Summary:\n";
//     cout << "---------------------\n";
//     cout << "Total Records (n) = " << n << endl;
//     cout << "Σx  = " << sumx << endl;
//     cout << "Σy  = " << sumy << endl;
//     cout << "Σx² = " << sumx2 << endl;
//     cout << "Σxy = " << sumxy << endl;

//     cout << "\nLinear Regression Results:\n";
//     cout << "---------------------------\n";
//     cout << "Slope (m)      = " << m << endl;
//     cout << "Intercept (c)  = " << c << endl;
//     cout << "Equation of Line: y = " << m << "x + " << c << endl;

//     // --- Optional: Predictions ---
//     cout << "\nEnter a value of x to predict y (or -999 to skip): ";
//     double xPred;
//     cin >> xPred;
//     if (xPred != -999) {
//         double yPred = m * xPred + c;
//         cout << "Predicted y = " << yPred << endl;
//     }

//     return 0;
// }
