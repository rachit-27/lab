#include <bits/stdc++.h>
using namespace std;

vector<string> splitCSVLine(const string &line) {
    vector<string> result;
    stringstream ss(line);
    string cell;
    while (getline(ss, cell, ',')) {
        result.push_back(cell);
    }
    return result;
}

double calculateCorrelation(const vector<double>& X, const vector<double>& Y) {
    int n = X.size();
    double meanX = accumulate(X.begin(), X.end(), 0.0) / n;
    double meanY = accumulate(Y.begin(), Y.end(), 0.0) / n;

    double numerator = 0.0, denomX = 0.0, denomY = 0.0;
    for (int i = 0; i < n; i++) {
        double dx = X[i] - meanX;
        double dy = Y[i] - meanY;
        numerator += dx * dy;
        denomX += dx * dx;
        denomY += dy * dy;
    }

    double denominator = sqrt(denomX * denomY);
    if (denominator == 0) return 0.0;
    return numerator / denominator;
}

int main() {
    string inputFilename = "Input.csv";
    ifstream file(inputFilename);
    if (!file.is_open()) {
        cout << "Error opening input file: " << inputFilename << endl;
        return 1;
    }

    string line;
    getline(file, line); 
    vector<string> header = splitCSVLine(line);

    vector<double> X, Y;
    while (getline(file, line)) {
        vector<string> row = splitCSVLine(line);
        if (row.size() >= 2) {
            X.push_back(stod(row[0]));
            Y.push_back(stod(row[1]));
        }
    }
    file.close();

    double r = calculateCorrelation(X, Y);
    string verdict;
    if (r == 0)
        verdict = "No correlation";
    else if (r > 0)
        verdict = "Positive correlation";
    else
        verdict = "Negative correlation";

    cout << "Correlation coefficient (r): " << r << endl;
    cout << "Type: " << verdict << endl;

    return 0;
}

// #include <bits/stdc++.h>
// using namespace std;

// vector<string> splitCSVLine(const string &line) {
//     vector<string> result;
//     stringstream ss(line);
//     string cell;
//     while (getline(ss, cell, ',')) {
//         result.push_back(cell);
//     }
//     return result;
// }

// // Same correlation logic as your original code
// double calculateCorrelation(const vector<double>& X, const vector<double>& Y) {
//     int n = X.size();
//     double meanX = accumulate(X.begin(), X.end(), 0.0) / n;
//     double meanY = accumulate(Y.begin(), Y.end(), 0.0) / n;

//     double numerator = 0.0, denomX = 0.0, denomY = 0.0;
//     for (int i = 0; i < n; i++) {
//         double dx = X[i] - meanX;
//         double dy = Y[i] - meanY;
//         numerator += dx * dy;
//         denomX += dx * dx;
//         denomY += dy * dy;
//     }

//     double denominator = sqrt(denomX * denomY);
//     if (denominator == 0) return 0.0;
//     return numerator / denominator;
// }

// bool isFloat(const string &s) {
//     try { stod(s); return true; } catch (...) { return false; }
// }

// int main() {
//     string inputFilename;
//     cout << "Enter CSV filename: ";
//     getline(cin, inputFilename);

//     ifstream file(inputFilename);
//     if (!file.is_open()) {
//         cout << "❌ Error opening input file: " << inputFilename << endl;
//         return 1;
//     }

//     string line;
//     getline(file, line); 
//     vector<string> header = splitCSVLine(line);

//     cout << "\nDetected Columns:\n";
//     for (int i = 0; i < header.size(); i++) {
//         cout << i << ": " << header[i] << endl;
//     }

//     int colX, colY;
//     cout << "\nEnter column index for X: ";
//     cin >> colX;
//     cout << "Enter column index for Y: ";
//     cin >> colY;

//     vector<double> X, Y;
//     while (getline(file, line)) {
//         vector<string> row = splitCSVLine(line);
//         if (colX < row.size() && colY < row.size()) {
//             string sx = row[colX];
//             string sy = row[colY];
//             if (isFloat(sx) && isFloat(sy)) {
//                 X.push_back(stod(sx));
//                 Y.push_back(stod(sy));
//             }
//         }
//     }
//     file.close();

//     if (X.empty() || Y.empty()) {
//         cout << "❌ No valid numeric data found for selected columns.\n";
//         return 1;
//     }

//     // --- Your original correlation logic ---
//     double r = calculateCorrelation(X, Y);

//     // Determine correlation type
//     string verdict;
//     if (r == 0)
//         verdict = "No correlation";
//     else if (r > 0)
//         verdict = "Positive correlation";
//     else
//         verdict = "Negative correlation";

//     // Print details (extended output, same logic)
//     cout << fixed << setprecision(4);
//     cout << "\n=====================================\n";
//     cout << "Correlation Analysis\n";
//     cout << "=====================================\n";
//     cout << "Selected Columns: " << header[colX] << " and " << header[colY] << endl;
//     cout << "Number of Records: " << X.size() << endl;
//     cout << "Correlation Coefficient (r): " << r << endl;
//     cout << "Type: " << verdict << endl;
// }
  
