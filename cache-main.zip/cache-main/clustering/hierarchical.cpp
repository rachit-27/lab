#include <bits/stdc++.h>
using namespace std;

struct Cluster {
    vector<string> items;
    Cluster() {}
    Cluster(const string& name) { items.push_back(name); }
};
double getDistance(const map<pair<string, string>, double>& distMap,
                   const string& a, const string& b) {
    if (a == b) return 0;
    auto it = distMap.find({a, b});
    if (it != distMap.end()) return it->second;
    return distMap.at({b, a});
}
double clusterDistance(const Cluster& c1, const Cluster& c2,
                       const map<pair<string, string>, double>& distMap,
                       const string& method) {
    double minD = DBL_MAX, maxD = 0, sum = 0;
    int count = 0;

    for (auto& i : c1.items)
        for (auto& j : c2.items) {
            double d = getDistance(distMap, i, j);
            minD = min(minD, d);
            maxD = max(maxD, d);
            sum += d;
            count++;
        }

    if (method == "single") return minD;
    if (method == "complete") return maxD;
    return sum / count; // average
}
void hierarchicalClustering(const vector<string>& labels,
                            const map<pair<string, string>, double>& distMap,
                            const string& method) {
    vector<Cluster> clusters;
    for (auto& l : labels)
        clusters.push_back(Cluster(l));

    cout << "\n" << method << " LINKAGE CLUSTERING:\n";

    while (clusters.size() > 1) {
        double minDist = DBL_MAX;
        int a = -1, b = -1;

        for (int i = 0; i < clusters.size(); i++) {
            for (int j = i + 1; j < clusters.size(); j++) {
                double d = clusterDistance(clusters[i], clusters[j], distMap, method);
                if (d < minDist) {
                    minDist = d;
                    a = i;
                    b = j;
                }
            }
        }

        cout << "Merging (";
        for (auto& x : clusters[a].items) cout << x;
        cout << ") and (";
        for (auto& y : clusters[b].items) cout << y;
        cout << ") at distance = " << minDist << endl;

        Cluster merged;
        merged.items.insert(merged.items.end(),
                            clusters[a].items.begin(), clusters[a].items.end());
        merged.items.insert(merged.items.end(),
                            clusters[b].items.begin(), clusters[b].items.end());

        if (b > a) {
            clusters.erase(clusters.begin() + b);
            clusters.erase(clusters.begin() + a);
        } else {
            clusters.erase(clusters.begin() + a);
            clusters.erase(clusters.begin() + b);
        }

        clusters.push_back(merged);
    }
}
int main() {
    string filename = "input.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening " << filename << endl;
        return 1;
    }
    string line;
    getline(file, line);
    vector<string> headers;
    stringstream ss(line);
    string val;
    getline(ss, val, ',');
    while (getline(ss, val, ','))
        headers.push_back(val);
    map<pair<string, string>, double> distMap;
    while (getline(file, line)) {
        stringstream ss(line);
        string rowLabel;
        getline(ss, rowLabel, ',');
        for (int i = 0; i < headers.size(); i++) {
            string cell;
            getline(ss, cell, ',');
            double d = stod(cell);
            distMap[{rowLabel, headers[i]}] = d;
        }
    }
    file.close();

    vector<string> linkages = {"single", "average", "complete"};
    for (auto& method : linkages)
        hierarchicalClustering(headers, distMap, method);

    return 0;
}


// #include <bits/stdc++.h>
// using namespace std;

// struct Cluster {
//     vector<string> items;
//     Cluster() {}
//     Cluster(const string& name) { items.push_back(name); }
// };

// // Get distance between two individual points
// double getDistance(const map<pair<string, string>, double>& distMap,
//                    const string& a, const string& b) {
//     if (a == b) return 0;
//     auto it = distMap.find({a, b});
//     if (it != distMap.end()) return it->second;
//     return distMap.at({b, a});
// }

// // Compute distance between two clusters based on linkage method
// double clusterDistance(const Cluster& c1, const Cluster& c2,
//                        const map<pair<string, string>, double>& distMap,
//                        const string& method) {
//     double minD = DBL_MAX, maxD = 0, sum = 0;
//     int count = 0;

//     for (auto& i : c1.items)
//         for (auto& j : c2.items) {
//             double d = getDistance(distMap, i, j);
//             minD = min(minD, d);
//             maxD = max(maxD, d);
//             sum += d;
//             count++;
//         }

//     if (method == "single") return minD;
//     if (method == "complete") return maxD;
//     return sum / count; // average linkage
// }

// // Function to print distance matrix between clusters
// void printDistanceMatrix(const vector<Cluster>& clusters,
//                          const map<pair<string, string>, double>& distMap,
//                          const string& method) {
//     cout << "\nCurrent Distance Matrix (" << method << " linkage):\n";
//     cout << setw(8) << " ";
//     for (auto& c : clusters) {
//         string name = "";
//         for (auto& x : c.items) name += x;
//         cout << setw(10) << name;
//     }
//     cout << "\n";

//     for (int i = 0; i < clusters.size(); i++) {
//         string rowName = "";
//         for (auto& x : clusters[i].items) rowName += x;
//         cout << setw(8) << rowName;
//         for (int j = 0; j < clusters.size(); j++) {
//             double d = (i == j) ? 0.0 : clusterDistance(clusters[i], clusters[j], distMap, method);
//             cout << setw(10) << fixed << setprecision(2) << d;
//         }
//         cout << "\n";
//     }
//     cout << "-----------------------------------------------\n";
// }

// // Hierarchical clustering with user-selected linkage
// void hierarchicalClustering(const vector<string>& labels,
//                             const map<pair<string, string>, double>& distMap,
//                             const string& method) {
//     vector<Cluster> clusters;
//     for (auto& l : labels)
//         clusters.push_back(Cluster(l));

//     cout << "\n==============================\n";
//     cout << method << " LINKAGE CLUSTERING\n";
//     cout << "==============================\n";

//     int step = 1;
//     while (clusters.size() > 1) {
//         printDistanceMatrix(clusters, distMap, method);

//         double minDist = DBL_MAX;
//         int a = -1, b = -1;

//         for (int i = 0; i < clusters.size(); i++) {
//             for (int j = i + 1; j < clusters.size(); j++) {
//                 double d = clusterDistance(clusters[i], clusters[j], distMap, method);
//                 if (d < minDist) {
//                     minDist = d;
//                     a = i;
//                     b = j;
//                 }
//             }
//         }

//         cout << "Step " << step++ << ": Merging (";
//         for (auto& x : clusters[a].items) cout << x;
//         cout << ") and (";
//         for (auto& y : clusters[b].items) cout << y;
//         cout << ") at distance = " << minDist << "\n";

//         Cluster merged;
//         merged.items.insert(merged.items.end(),
//                             clusters[a].items.begin(), clusters[a].items.end());
//         merged.items.insert(merged.items.end(),
//                             clusters[b].items.begin(), clusters[b].items.end());

//         if (b > a) {
//             clusters.erase(clusters.begin() + b);
//             clusters.erase(clusters.begin() + a);
//         } else {
//             clusters.erase(clusters.begin() + a);
//             clusters.erase(clusters.begin() + b);
//         }

//         clusters.push_back(merged);
//     }

//     cout << "\nFinal Cluster Formed: (";
//     for (auto& x : clusters[0].items)
//         cout << x << " ";
//     cout << ")\n";
// }

// int main() {
//     string filename;
//     cout << "Enter CSV filename: ";
//     getline(cin, filename);

//     ifstream file(filename);
//     if (!file.is_open()) {
//         cout << "Error opening " << filename << endl;
//         return 1;
//     }

//     string line;
//     getline(file, line);
//     vector<string> headers;
//     stringstream ss(line);
//     string val;
//     getline(ss, val, ',');
//     while (getline(ss, val, ','))
//         headers.push_back(val);

//     map<pair<string, string>, double> distMap;
//     while (getline(file, line)) {
//         stringstream ss(line);
//         string rowLabel;
//         getline(ss, rowLabel, ',');
//         for (int i = 0; i < headers.size(); i++) {
//             string cell;
//             getline(ss, cell, ',');
//             double d = stod(cell);
//             distMap[{rowLabel, headers[i]}] = d;
//         }
//     }
//     file.close();

//     // User chooses method
//     cout << "\nChoose linkage method:\n";
//     cout << "1. Single Linkage\n";
//     cout << "2. Complete Linkage\n";
//     cout << "3. Average Linkage\n";
//     cout << "Enter choice (1-3): ";
//     int choice;
//     cin >> choice;

//     string method;
//     if (choice == 1) method = "single";
//     else if (choice == 2) method = "complete";
//     else method = "average";

//     hierarchicalClustering(headers, distMap, method);

//     return 0;
// }

