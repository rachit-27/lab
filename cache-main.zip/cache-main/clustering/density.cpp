#include <bits/stdc++.h>
using namespace std;

struct Point {
    vector<double> values;
    bool visited = false;
    int cluster = 0;

    Point(vector<double> vals) {
        values = vals;
    }

    double distance(const Point& other) const {
        double sum = 0.0;
        for (size_t i = 0; i < values.size(); i++)
            sum += pow(values[i] - other.values[i], 2);
        return sqrt(sum);
    }
};

vector<Point> readDataset(const string& filename) {
    vector<Point> points;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return points;
    }

    string line;
    bool firstLine = true;
    while (getline(file, line)) {
        if (firstLine) { 
            firstLine = false; 
            continue; 
        }
        if (line.empty()) continue;

        stringstream ss(line);
        string id, x, y;
        getline(ss, id, ',');  // skip Point ID
        getline(ss, x, ',');
        getline(ss, y, ',');

        points.emplace_back(vector<double>{stod(x), stod(y)});
    }

    file.close();
    return points;
}

vector<Point*> regionQuery(vector<Point>& dataset, Point& p, double eps) {
    vector<Point*> neighbors;
    for (auto& other : dataset) {
        if (p.distance(other) <= eps)
            neighbors.push_back(&other);
    }
    return neighbors;
}

void expandCluster(Point& p, vector<Point*>& neighbors, int clusterId,
                   vector<Point>& dataset, double eps, int minPts) {
    p.cluster = clusterId;
    queue<Point*> q;
    for (auto* n : neighbors) q.push(n);

    while (!q.empty()) {
        Point* current = q.front();
        q.pop();

        if (!current->visited) {
            current->visited = true;
            vector<Point*> newNeighbors = regionQuery(dataset, *current, eps);
            if ((int)newNeighbors.size() >= minPts) {
                for (auto* np : newNeighbors) q.push(np);
            }
        }

        if (current->cluster == 0)
            current->cluster = clusterId;
    }
}

void dbscan(vector<Point>& dataset, double eps, int minPts) {
    int clusterId = 0;
    for (auto& p : dataset) {
        if (!p.visited) {
            p.visited = true;
            vector<Point*> neighbors = regionQuery(dataset, p, eps);
            if ((int)neighbors.size() < minPts) {
                p.cluster = -1; // noise
            } else {
                clusterId++;
                expandCluster(p, neighbors, clusterId, dataset, eps, minPts);
            }
        }
    }
}

int main() {
    string filename = "input.csv"; 
    vector<Point> dataset = readDataset(filename);

    if (dataset.empty()) {
        cout << "Dataset not found or empty!" << endl;
        return 0;
    }

    double eps;
    int minPts;
    cout << "Enter epsilon (eps): ";
    cin >> eps;
    cout << "Enter minimum points (minPts): ";
    cin >> minPts;

    dbscan(dataset, eps, minPts);

    unordered_map<int, int> clusterCount;
    for (auto& p : dataset)
        clusterCount[p.cluster]++;

    int total = dataset.size();
    cout << "\nCluster Percentage Distribution:\n";
    for (auto& kv : clusterCount) {
        string name = (kv.first == -1) ? "Noise" : "Cluster " + to_string(kv.first);
        double percent = (kv.second * 100.0) / total;
        cout << name << ": " << kv.second << " points (" << fixed << setprecision(2) << percent << "%)\n";
    }

    return 0;
}



// #include <bits/stdc++.h>
// using namespace std;

// // ---------- STRUCT DEFINITION ----------
// struct Point {
//     int id;
//     vector<double> values;
//     bool visited = false;
//     int cluster = 0;
//     vector<int> neighbors; // store neighbor indices

//     Point(int i, vector<double> vals) {
//         id = i;
//         values = vals;
//     }

//     double distance(const Point& other) const {
//         double sum = 0.0;
//         for (size_t i = 0; i < values.size(); i++)
//             sum += pow(values[i] - other.values[i], 2);
//         return sqrt(sum);
//     }
// };

// // ---------- READ CSV (Header Safe + NaN Placeholders) ----------
// vector<vector<double>> readCSV(const string& filename) {
//     vector<vector<double>> data;
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: Could not open file " << filename << endl;
//         return data;
//     }

//     string line;
//     getline(file, line); // Skip header row

//     while (getline(file, line)) {
//         if (line.empty()) continue;
//         stringstream ss(line);
//         string value;
//         vector<double> row;
//         while (getline(ss, value, ',')) {
//             try {
//                 row.push_back(stod(value));
//             } catch (...) {
//                 row.push_back(numeric_limits<double>::quiet_NaN()); // keep alignment
//             }
//         }
//         if (!row.empty()) data.push_back(row);
//     }
//     file.close();
//     return data;
// }

// // ---------- SELECT COLUMNS ----------
// vector<Point> selectColumns(const vector<vector<double>>& data, const vector<int>& cols) {
//     vector<Point> points;
//     int id = 1;
//     for (auto& row : data) {
//         vector<double> selected;
//         for (int idx : cols) {
//             if (idx < (int)row.size() && !isnan(row[idx]))
//                 selected.push_back(row[idx]);
//         }
//         if (!selected.empty()) points.emplace_back(id++, selected);
//     }
//     return points;
// }

// // ---------- REGION QUERY ----------
// vector<int> regionQuery(vector<Point>& dataset, int idx, double eps) {
//     vector<int> neighbors;
//     for (int i = 0; i < dataset.size(); i++) {
//         if (dataset[idx].distance(dataset[i]) <= eps)
//             neighbors.push_back(i);
//     }
//     return neighbors;
// }

// // ---------- EXPAND CLUSTER ----------
// void expandCluster(vector<Point>& dataset, int idx, vector<int>& neighbors, int clusterId, double eps, int minPts) {
//     dataset[idx].cluster = clusterId;
//     queue<int> q;
//     for (int n : neighbors) q.push(n);

//     while (!q.empty()) {
//         int current = q.front();
//         q.pop();

//         if (!dataset[current].visited) {
//             dataset[current].visited = true;
//             vector<int> newNeighbors = regionQuery(dataset, current, eps);
//             if ((int)newNeighbors.size() >= minPts) {
//                 for (int nn : newNeighbors) q.push(nn);
//             }
//         }
//         if (dataset[current].cluster == 0)
//             dataset[current].cluster = clusterId;
//     }
// }

// // ---------- DBSCAN ----------
// void dbscan(vector<Point>& dataset, double eps, int minPts) {
//     int clusterId = 0;

//     // Compute neighbors for all points first
//     for (int i = 0; i < dataset.size(); i++) {
//         dataset[i].neighbors = regionQuery(dataset, i, eps);
//     }

//     for (auto& p : dataset) {
//         if (!p.visited) {
//             p.visited = true;
//             if ((int)p.neighbors.size() < minPts) {
//                 p.cluster = -1; // noise
//             } else {
//                 clusterId++;
//                 expandCluster(dataset, p.id - 1, p.neighbors, clusterId, eps, minPts);
//             }
//         }
//     }
// }

// // ---------- MAIN ----------
// int main() {
//     string filename;
//     cout << "Enter CSV filename: ";
//     getline(cin, filename);

//     vector<vector<double>> data = readCSV(filename);
//     if (data.empty()) {
//         cout << "Dataset not found or empty!" << endl;
//         return 0;
//     }

//     cout << "Enter column indices to use (space separated, 0-based): ";
//     string colInput;
//     getline(cin, colInput);
//     stringstream ss(colInput);
//     vector<int> cols; int temp;
//     while (ss >> temp) cols.push_back(temp);

//     vector<Point> dataset = selectColumns(data, cols);
//     if (dataset.empty()) {
//         cerr << "Error: No valid numeric data found in selected columns.\n";
//         return 0;
//     }

//     double eps;
//     int minPts;
//     cout << "Enter epsilon (eps): ";
//     cin >> eps;
//     cout << "Enter minimum points (minPts): ";
//     cin >> minPts;

//     int n = dataset.size();

//     // ---------- Print Distance Matrix ----------
//     cout << "\nDistance Matrix:\n     ";
//     for (int i = 0; i < n; i++) cout << "P" << i + 1 << "\t";
//     cout << "\n";
//     for (int i = 0; i < n; i++) {
//         cout << "P" << i + 1 << "\t";
//         for (int j = 0; j < n; j++) {
//             cout << fixed << setprecision(2) << dataset[i].distance(dataset[j]) << "\t";
//         }
//         cout << "\n";
//     }

//     // ---------- Run DBSCAN ----------
//     dbscan(dataset, eps, minPts);

//     // ---------- Print Neighbors ----------
//     cout << "\nNeighbors (within eps = " << eps << "):\n";
//     for (int i = 0; i < n; i++) {
//         cout << "P" << i + 1 << " -> ";
//         for (int idx : dataset[i].neighbors)
//             cout << "P" << idx + 1 << " ";
//         cout << endl;
//     }

//     // ---------- Identify Core, Border, and Noise ----------
//     vector<int> core, border, noise;
//     for (int i = 0; i < n; i++) {
//         if (dataset[i].cluster == -1)
//             noise.push_back(i + 1);
//         else if ((int)dataset[i].neighbors.size() >= minPts)
//             core.push_back(i + 1);
//         else
//             border.push_back(i + 1);
//     }

//     cout << "\nCore Points: ";
//     for (int p : core) cout << "P" << p << " ";
//     cout << "\nBorder Points: ";
//     for (int p : border) cout << "P" << p << " ";
//     cout << "\nNoise Points: ";
//     for (int p : noise) cout << "P" << p << " ";
//     cout << endl;

//     // ---------- Print Cluster Members ----------
//     unordered_map<int, vector<int>> clusters;
//     for (int i = 0; i < n; i++) {
//         clusters[dataset[i].cluster].push_back(i + 1);
//     }

//     cout << "\nCluster Members:\n";
//     for (auto& kv : clusters) {
//         if (kv.first == -1) continue;
//         cout << "Cluster " << kv.first << " -> ";
//         for (int pid : kv.second) cout << "P" << pid << " ";
//         cout << endl;
//     }

//     if (!clusters.count(-1))
//         cout << "No noise points.\n";
//     else if (!clusters[-1].empty())
//         cout << "Noise points: ";
//     for (int pid : clusters[-1]) cout << "P" << pid << " ";
//     cout << endl;

//     return 0;
// }
