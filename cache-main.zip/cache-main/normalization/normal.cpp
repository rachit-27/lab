#include <bits/stdc++.h>
using namespace std;

bool isFloat(const string &s) {
    try {
        stod(s);
        return true;
    } catch (...) {
        return false;
    }
}

// Function to normalize column by method
vector<double> normalizeColumn(const vector<double>& col, int method) {
    vector<double> normCol;
    if (method == 1) { // Min-Max
        double minVal = *min_element(col.begin(), col.end());
        double maxVal = *max_element(col.begin(), col.end());
        for (double x : col)
            normCol.push_back((maxVal != minVal) ? (x - minVal) / (maxVal - minVal) : 0.0);
    } 
    else if (method == 2) { // Z-Score
        double mean = accumulate(col.begin(), col.end(), 0.0) / col.size();
        double sqSum = 0;
        for (double x : col) sqSum += (x - mean) * (x - mean);
        double stddev = sqrt(sqSum / col.size());
        for (double x : col)
            normCol.push_back((stddev != 0) ? (x - mean) / stddev : 0.0);
    } 
    else if (method == 3) { // Decimal Scaling
        double maxAbs = 0;
        for (double x : col) maxAbs = max(maxAbs, fabs(x));
        int j = (maxAbs != 0) ? to_string((long long)maxAbs).length() : 1;
        for (double x : col) normCol.push_back(x / pow(10, j));
    }
    return normCol;
}

// Function to apply normalization method to entire dataset
vector<vector<string>> applyNormalization(
    int method,
    const vector<string>& header,
    const vector<vector<string>>& rows,
    const vector<int>& numCols)
{
    int colCount = header.size();
    vector<vector<string>> columns(colCount);
    for (int c = 0; c < colCount; c++) {
        for (auto &row : rows) {
            columns[c].push_back(row[c]);
        }
    }

    vector<vector<string>> normalizedCols;

    for (int c = 0; c < colCount; c++) {
        if (find(numCols.begin(), numCols.end(), c) != numCols.end()) {
            vector<double> col;
            for (auto &v : columns[c]) col.push_back(stod(v));

            vector<double> normCol = normalizeColumn(col, method);

            vector<string> normStr;
            for (double val : normCol) {
                ostringstream oss;
                oss << fixed << setprecision(6) << val;
                normStr.push_back(oss.str());
            }
            normalizedCols.push_back(normStr);
        }
        else {
            normalizedCols.push_back(columns[c]);
        }
    }

    // Transpose back to rows
    vector<vector<string>> normalizedRows(rows.size(), vector<string>(colCount));
    for (int c = 0; c < colCount; c++) {
        for (int r = 0; r < rows.size(); r++) {
            normalizedRows[r][c] = normalizedCols[c][r];
        }
    }

    return normalizedRows;
}

// Function to save CSV
void saveCSV(const vector<string>& header, const vector<vector<string>>& normalizedRows, const string& outFile) {
    ofstream out(outFile);
    for (int i = 0; i < header.size(); i++) {
        out << header[i] << (i < header.size() - 1 ? "," : "\n");
    }
    for (auto &row : normalizedRows) {
        for (int i = 0; i < row.size(); i++) {
            out << row[i] << (i < row.size() - 1 ? "," : "\n");
        }
    }
    out.close();
    cout << "Normalized data saved to '" << outFile << "'\n";
}

// Function to print first 5 rows
void printPreview(const vector<string>& header, const vector<vector<string>>& rows, const string& title) {
    cout << "\n--- " << title << "\n";
    for (auto &h : header) cout << h << "\t";
    cout << "\n";
    for (int r = 0; r < min((int)rows.size(), 5); r++) {
        for (auto &cell : rows[r]) cout << cell << "\t";
        cout << "\n";
    }
}

int main() {
    string fileName;
    cout << "Enter the CSV file name: ";
    cin >> fileName;

    ifstream file(fileName);
    if (!file.is_open()) {
        cerr << "File not found." << endl;
        return 1;
    }

    vector<string> header;
    vector<vector<string>> rows;
    string line;

    // Read header
    if (getline(file, line)) {
        stringstream ss(line);
        string cell;
        while (getline(ss, cell, ',')) {
            header.push_back(cell);
        }
    }

    // Read rows
    while (getline(file, line)) {
        stringstream ss(line);
        string cell;
        vector<string> row;
        while (getline(ss, cell, ',')) {
            row.push_back(cell);
        }
        rows.push_back(row);
    }
    file.close();

    int colCount = header.size();
    vector<int> numCols;

    // Detect numeric columns
    for (int c = 0; c < colCount; c++) {
        bool allNum = true;
        for (auto &row : rows) {
            if (!isFloat(row[c])) {
                allNum = false;
                break;
            }
        }
        if (allNum) numCols.push_back(c);
    }

    // Choose normalization method
    int choice;
    cout << "\nChoose Normalization Method:\n";
    cout << "1. Min-Max Normalization\n";
    cout << "2. Z-Score Normalization\n";
    cout << "3. Decimal Scaling Normalization\n";
    cout << "4. All Methods\n";
    cout << "Enter choice (1/2/3/4): ";
    cin >> choice;

    if (choice >= 1 && choice <= 3) {
        auto normalizedRows = applyNormalization(choice, header, rows, numCols);
        printPreview(header, normalizedRows, "Normalized Data");
        
        string outFile;
        if (choice == 1) outFile = "minmax_normalized.csv";
        else if (choice == 2) outFile = "zscore_normalized.csv";
        else if (choice == 3) outFile = "decimalscaling_normalized.csv";

        saveCSV(header, normalizedRows, outFile);
    } 
    else if (choice == 4) {
        vector<string> titles = {"Min-Max Normalization", "Z-Score Normalization", "Decimal Scaling Normalization"};
        vector<string> outFiles = {"minmax_normalized.csv", "zscore_normalized.csv", "decimalscaling_normalized.csv"};
        for (int m = 1; m <= 3; m++) {
            auto normalizedRows = applyNormalization(m, header, rows, numCols);
            printPreview(header, normalizedRows, titles[m-1]);
            saveCSV(header, normalizedRows, outFiles[m-1]);
        }
    } 
    else {
        cout << "Invalid choice." << endl;
    }

    return 0;
}




// #include <bits/stdc++.h>
// using namespace std;

// bool isFloat(const string &s) {
//     try { stod(s); return true; } catch (...) { return false; }
// }

// // Function to normalize column by selected method
// vector<double> normalizeColumn(const vector<double>& col, int method) {
//     vector<double> normCol;
//     if (method == 1) { // Min-Max
//         double minVal = *min_element(col.begin(), col.end());
//         double maxVal = *max_element(col.begin(), col.end());
//         for (double x : col)
//             normCol.push_back((maxVal != minVal) ? (x - minVal) / (maxVal - minVal) : 0.0);
//     } 
//     else if (method == 2) { // Z-Score
//         double mean = accumulate(col.begin(), col.end(), 0.0) / col.size();
//         double sqSum = 0;
//         for (double x : col) sqSum += (x - mean) * (x - mean);
//         double stddev = sqrt(sqSum / col.size());
//         for (double x : col)
//             normCol.push_back((stddev != 0) ? (x - mean) / stddev : 0.0);
//     } 
//     else if (method == 3) { // Decimal Scaling
//         double maxAbs = 0;
//         for (double x : col) maxAbs = max(maxAbs, fabs(x));
//         int j = (maxAbs != 0) ? to_string((long long)maxAbs).length() : 1;
//         for (double x : col) normCol.push_back(x / pow(10, j));
//     }
//     return normCol;
// }

// // Apply normalization to selected columns only
// vector<vector<string>> normalizeSelectedColumns(
//     int method,
//     const vector<vector<string>>& rows,
//     const vector<int>& colsToNormalize)
// {
//     vector<vector<string>> normalizedData(rows.size(), vector<string>(colsToNormalize.size()));
//     for (int i = 0; i < colsToNormalize.size(); i++) {
//         int c = colsToNormalize[i];
//         vector<double> col;
//         for (auto &row : rows) col.push_back(stod(row[c]));
//         vector<double> normCol = normalizeColumn(col, method);
//         for (int r = 0; r < rows.size(); r++) {
//             ostringstream oss;
//             oss << fixed << setprecision(6) << normCol[r];
//             normalizedData[r][i] = oss.str();
//         }
//     }
//     return normalizedData;
// }

// // Save normalized CSV (only selected columns)
// void saveCSVSelected(const vector<string>& headers, const vector<vector<string>>& normalizedData, const string& outFile) {
//     ofstream out(outFile);
//     for (int i = 0; i < headers.size(); i++)
//         out << headers[i] << (i < headers.size() - 1 ? "," : "\n");
//     for (auto &row : normalizedData) {
//         for (int i = 0; i < row.size(); i++)
//             out << row[i] << (i < row.size() - 1 ? "," : "\n");
//     }
//     out.close();
//     cout << "✅ Normalized columns saved to '" << outFile << "'\n";
// }

// // Print preview (first 5 rows)
// void printPreview(const vector<string>& headers, const vector<vector<string>>& data, const string& title) {
//     cout << "\n--- " << title << " ---\n";
//     for (auto &h : headers) cout << setw(12) << h;
//     cout << "\n";
//     for (int r = 0; r < min((int)data.size(), 5); r++) {
//         for (auto &cell : data[r]) cout << setw(12) << cell;
//         cout << "\n";
//     }
// }

// int main() {
//     string fileName;
//     cout << "Enter the CSV file name: ";
//     cin >> fileName;

//     ifstream file(fileName);
//     if (!file.is_open()) {
//         cerr << "❌ File not found.\n";
//         return 1;
//     }

//     vector<string> header;
//     vector<vector<string>> rows;
//     string line;

//     // Read header
//     if (getline(file, line)) {
//         stringstream ss(line);
//         string cell;
//         while (getline(ss, cell, ',')) header.push_back(cell);
//     }

//     // Read rows
//     while (getline(file, line)) {
//         stringstream ss(line);
//         string cell;
//         vector<string> row;
//         while (getline(ss, cell, ',')) row.push_back(cell);
//         rows.push_back(row);
//     }
//     file.close();

//     int colCount = header.size();
//     vector<int> numericCols;

//     // Detect numeric columns
//     for (int c = 0; c < colCount; c++) {
//         bool allNum = true;
//         for (auto &row : rows) {
//             if (!isFloat(row[c])) { allNum = false; break; }
//         }
//         if (allNum) numericCols.push_back(c);
//     }

//     cout << "\nDetected Numeric Columns:\n";
//     for (int c : numericCols)
//         cout << c << ": " << header[c] << endl;

//     // Choose which columns to normalize
//     cout << "\nEnter column indices to normalize (space-separated, e.g., 2 3): ";
//     string input;
//     cin.ignore();
//     getline(cin, input);
//     stringstream ss(input);
//     vector<int> colsToNormalize;
//     int idx;
//     while (ss >> idx) colsToNormalize.push_back(idx);

//     // Choose normalization method
//     int choice;
//     cout << "\nChoose Normalization Method:\n";
//     cout << "1. Min-Max Normalization\n";
//     cout << "2. Z-Score Normalization\n";
//     cout << "3. Decimal Scaling Normalization\n";
//     cout << "Enter choice (1/2/3): ";
//     cin >> choice;

//     if (choice < 1 || choice > 3) {
//         cerr << "Invalid choice.\n";
//         return 1;
//     }

//     // Normalize selected columns only
//     vector<vector<string>> normalizedData = normalizeSelectedColumns(choice, rows, colsToNormalize);

//     // Extract selected column headers
//     vector<string> selectedHeaders;
//     for (int c : colsToNormalize) selectedHeaders.push_back(header[c]);

//     // Print preview
//     printPreview(selectedHeaders, normalizedData, "Normalized Columns Only");

//     // Save output file
//     string outFile;
//     if (choice == 1) outFile = "minmax_normalized_selected.csv";
//     else if (choice == 2) outFile = "zscore_normalized_selected.csv";
//     else if (choice == 3) outFile = "decimalscaling_normalized_selected.csv";

//     saveCSVSelected(selectedHeaders, normalizedData, outFile);

//     return 0;
// }
