def read_csv(filename):
    dataset = []
    labels = []
    with open(filename, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            dataset.append(parts[:-1])
            labels.append(parts[-1])
    return dataset, labels

def summarize_by_class(dataset, labels):
    summaries = {}
    for cls in set(labels):
        cls_rows = [dataset[i] for i in range(len(dataset)) if labels[i] == cls]
        feature_counts = []
        for col in zip(*cls_rows):
            counts = {}
            for value in col:
                counts[value] = counts.get(value, 0) + 1
            feature_counts.append(counts)
        summaries[cls] = feature_counts
    return summaries

def calculate_class_probabilities(summaries, labels, input_vector):
    total_count = len(labels)
    label_counts = {cls: labels.count(cls) for cls in set(labels)}
    probabilities = {}
    
    for cls, feature_counts in summaries.items():
        prob = label_counts[cls] / total_count
        for i, value in enumerate(input_vector):
            count = feature_counts[i].get(value, 0) + 1
            total = sum(feature_counts[i].values()) + len(feature_counts[i])
            prob *= count / total
        probabilities[cls] = prob
    return probabilities

def predict(summaries, labels, input_vector):
    probs = calculate_class_probabilities(summaries, labels, input_vector)
    best_label = max(probs, key=probs.get)
    return best_label

if __name__ == "__main__":
    choice = input("Do you want to use CSV file? (y/n): ").strip().lower()

    if choice == "y":
        filename = input("Enter CSV filename: ").strip()
        dataset, labels = read_csv(filename)
    else:
        n = int(input("Enter number of data points: "))
        m = int(input("Enter number of features: "))
        dataset = []
        labels = []
        print("Enter data row by row (features followed by label, space-separated):")
        for _ in range(n):
            row = input().strip().split()
            if len(row) != m + 1:
                print(f"Error: each row must have {m} features + 1 label")
                exit()
            dataset.append(row[:-1])
            labels.append(row[-1])

    summaries = summarize_by_class(dataset, labels)

    print("\nEnter feature values to predict:")
    input_vector = input().strip().split()
    if len(input_vector) != len(dataset[0]):
        print(f"Error: input must have {len(dataset[0])} feature values")
        exit()

    predicted_label = predict(summaries, labels, input_vector)
    print(f"\nPredicted class: {predicted_label}")
