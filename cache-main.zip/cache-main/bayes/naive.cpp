#include <bits/stdc++.h>
using namespace std;

vector<string> split(const string &s, char d) {
    vector<string> t; string x; stringstream ss(s);
    while (getline(ss, x, d)) t.push_back(x);
    return t;
}

int main() {
    string filename;
    cout << "Enter CSV filename: ";
    cin >> filename;

    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Cannot open file.\n";
        return 1;
    }

    string line;
    getline(file, line);
    vector<string> headers = split(line, ',');
    int n = headers.size() - 1;

    vector<vector<string>> data;
    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() == headers.size()) data.push_back(row);
    }
    file.close();

    map<string, int> classCount;
    for (auto &r : data) classCount[r.back()]++;
    int total = data.size();

    cout << "\nPrior Probabilities:\n";
    map<string, double> prior;
    for (auto &c : classCount) {
        prior[c.first] = (double)c.second / total;
        cout << "P(" << c.first << ") = " << classCount[c.first] << "/" << total
             << " = " << fixed << setprecision(3) << prior[c.first] << endl;
    }

    cout << "\nConditional Probabilities:\n";
    map<string, map<string, map<string, double>>> featureProb;
    for (int i = 0; i < n; i++) {
        map<string, map<string, int>> freq;
        for (auto &r : data) freq[r.back()][r[i]]++;

        for (auto &c : classCount) {
            cout << "\nFor Class = " << c.first << " (" << headers[i] << "):\n";
            for (auto &f : freq[c.first]) {
                featureProb[headers[i]][c.first][f.first] =
                    (double)f.second / classCount[c.first];
                cout << "P(" << f.first << " | " << c.first << ") = "
                     << f.second << "/" << classCount[c.first]
                     << " = " << featureProb[headers[i]][c.first][f.first] << endl;
            }
        }
    }

    cout << "\nEnter values for a test case:\n";
    map<string, string> inst;
    for (int i = 0; i < n; i++) {
        string v;
        cout << headers[i] << ": ";
        cin >> v;
        inst[headers[i]] = v;
    }

    cout << "\nCalculation of Posterior Probabilities:\n";
    map<string, double> post;

    for (auto &c : classCount) {
        double prob = prior[c.first];
        cout << "\nFor " << c.first << ":\n";
        cout << "P(" << c.first << ") = " << prior[c.first] << endl;
        for (int i = 0; i < n; i++) {
            string f = headers[i], v = inst[f];
            double cond = featureProb[f][c.first].count(v) ?
                          featureProb[f][c.first][v] : 0.0;
            cout << "P(" << v << " | " << c.first << ") = " << cond << endl;
            prob *= cond;
        }
        cout << "=> Final P(" << c.first << " | Case) = " << prob << endl;
        post[c.first] = prob;
    }

    cout << "\nComparison:\n";
    for (auto &p : post)
        cout << "P(" << p.first << " | Case) = " << p.second << endl;

    string pred = max_element(post.begin(), post.end(),
                              [](auto &a, auto &b) {
                                  return a.second < b.second;
                              })->first;

    cout << "\nBased on calculations:\nPredicted classification for case is "
         << pred << endl;

    return 0;
}
