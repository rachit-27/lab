#include <bits/stdc++.h>
using namespace std;

double entropy(const map<string, int>& classCount) {
    double total = 0.0;
    for (auto &p : classCount) total += p.second;
    double ent = 0.0;
    for (auto &p : classCount) {
        if (p.second == 0) continue;
        double p_i = p.second / total;
        ent -= p_i * log2(p_i);
    }
    return ent;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string filename = "dataG.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: cannot open " << filename << endl;
        return 1;
    }

    string line;
    getline(file, line);
    vector<string> headers;
    stringstream ss(line);
    string col;
    while (getline(ss, col, ',')) headers.push_back(col);

    int numCols = headers.size();
    vector<vector<string>> data;
    while (getline(file, line)) {
        stringstream s(line);
        vector<string> row;
        string val;
        while (getline(s, val, ',')) row.push_back(val);
        if (row.size() == numCols)
            data.push_back(row);
    }
    file.close();

    int total = data.size();
    string classCol = headers.back();

    map<string, int> classCount;
    for (auto &row : data) classCount[row.back()]++;

    double totalEntropy = entropy(classCount);
    cout << fixed << setprecision(6);
    cout << "Overall Entropy = " << totalEntropy << "\n\n";

    for (int attr = 0; attr < numCols - 1; ++attr) {
        map<string, map<string, int>> subsets;
        for (auto &row : data) {
            string attrVal = row[attr];
            string classVal = row.back();
            subsets[attrVal][classVal]++;
        }

        double weightedEntropy = 0.0;
        for (auto &kv : subsets) {
            double subsetSize = 0;
            for (auto &p : kv.second) subsetSize += p.second;
            weightedEntropy += (subsetSize / total) * entropy(kv.second);
        }

        double infoGain = totalEntropy - weightedEntropy;

        cout << "Attribute: " << headers[attr] << "\n";
        cout << "Weighted Entropy = " << weightedEntropy << "\n";
        cout << "Information Gain = " << infoGain << "\n\n";
    }

    return 0;
}

// #include <bits/stdc++.h>
// using namespace std;

// // Function to compute entropy of a class distribution
// double entropy(const map<string, int>& classCount) {
//     double total = 0.0;
//     for (auto &p : classCount) total += p.second;

//     double ent = 0.0;
//     for (auto &p : classCount) {
//         if (p.second == 0) continue;
//         double p_i = p.second / total;
//         ent -= p_i * log2(p_i);
//     }
//     return ent;
// }

// int main() {
//     string filename = "dataG.csv";
//     ifstream file(filename);
//     if (!file.is_open()) {
//         cerr << "Error: cannot open " << filename << endl;
//         return 1;
//     }

//     string line;
//     getline(file, line);
//     vector<string> headers;
//     stringstream ss(line);
//     string col;
//     while (getline(ss, col, ',')) headers.push_back(col);

//     int numCols = headers.size();
//     vector<vector<string>> data;

//     // Read all rows into data vector
//     while (getline(file, line)) {
//         stringstream s(line);
//         vector<string> row;
//         string val;
//         while (getline(s, val, ',')) row.push_back(val);
//         if (row.size() == numCols)
//             data.push_back(row);
//     }
//     file.close();

//     int total = data.size();

//     // Count occurrences of each class
//     map<string, int> classCount;
//     for (auto &row : data) classCount[row.back()]++;

//     // Compute total entropy of dataset
//     double totalEntropy = entropy(classCount);
//     cout << fixed << setprecision(6);
//     cout << "Overall Entropy = " << totalEntropy << "\n\n";

//     // --- CHANGED PART: Ask user for attribute name ---
//     cout << "Attributes: ";
//     for (int i = 0; i < numCols - 1; i++)
//         cout << headers[i] << "  ";
//     cout << "\nEnter the attribute name to compute info gain: ";
//     string chosenAttr;
//     cin >> chosenAttr;

//     // --- CHANGED PART: Find the index of the chosen attribute ---
//     int attrIndex = -1;
//     for (int i = 0; i < numCols - 1; ++i) {
//         if (headers[i] == chosenAttr) {
//             attrIndex = i;
//             break;
//         }
//     }
//     if (attrIndex == -1) {  // Invalid input check
//         cout << "Invalid attribute name!\n";
//         return 1;
//     }

//     // --- CHANGED PART: Compute weighted entropy and info gain for only that attribute ---
//     map<string, map<string, int>> subsets; // store counts of class for each attribute value
//     for (auto &row : data) {
//         string attrVal = row[attrIndex];
//         string classVal = row.back();
//         subsets[attrVal][classVal]++;
//     }

//     double weightedEntropy = 0.0;
//     for (auto &kv : subsets) {
//         double subsetSize = 0;
//         for (auto &p : kv.second) subsetSize += p.second;
//         weightedEntropy += (subsetSize / total) * entropy(kv.second);
//     }

//     double infoGain = totalEntropy - weightedEntropy;

//     // Display results
//     cout << "Attribute: " << headers[attrIndex] << "\n";
//     cout << "Weighted Entropy = " << weightedEntropy << "\n";
//     cout << "Information Gain = " << infoGain << "\n";

//     return 0;
// }
